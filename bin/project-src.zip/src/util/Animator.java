package finalProject.src.util;

import java.util.Observer;
  
/**
 * An interface for displaying simulations.
 */
public interface Animator extends Observer {
  public void dispose();
}


