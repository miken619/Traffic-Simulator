package finalProject.src.ui;

public interface UIMenuAction {
  public void run();
}
